#include <iostream>
#include <unistd.h>
#include <cstdlib>
using namespace std;
int main(int argc, char** argv){

    int timer;
    timer = atoi(argv[1]);
    
    int pid, ppid;
    int i = 0;
    
    cout << "Child PID: " << getppid() << "\n";
    cout << "Parent PID: " << getpid() << "\n";

    while (i < timer) {
        
        i++;
        cout << "Process: " << getppid() << " " << i <<"\n";
    }
    
    cout << "Process " << getppid() << " exited with status: " << i << "\n";
    return 0;

}
